package com.example.instadoodle

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.Toast

class DrawService : AccessibilityService() {

    companion object {
        var instance: DrawService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: Button? = null
    private var drawing = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        removeOverlay()
        instance = null
        super.onDestroy()
    }

    /** Screen par chhota floating Play button dikhata hai (top-right). */
    fun showOverlay() {
        if (overlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val btn = Button(this).apply {
            text = "▶ Draw"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E1306C"))
            setOnClickListener {
                if (drawing) { drawing = false; text = "▶ Draw" }
                else startDrawing()
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            y = 200
        }
        wm.addView(btn, lp)
        overlay = btn
    }

    fun removeOverlay() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }

    private fun startDrawing() {
        val strokes = StrokeStore.strokes
        if (strokes.isEmpty()) {
            Toast.makeText(this, "Pehle app me PNG chuniye", Toast.LENGTH_SHORT).show()
            return
        }
        val dm = resources.displayMetrics
        val sw = dm.widthPixels.toFloat()
        val sh = dm.heightPixels.toFloat()

        // Drawing area: screen ke beech me, image ke aspect ratio me.
        // Zarurat ho to 0.9f / 0.55f / 0.48f ko adjust karo.
        val scale = minOf(sw * 0.9f / StrokeStore.gridW, sh * 0.55f / StrokeStore.gridH)
        val offX = (sw - StrokeStore.gridW * scale) / 2f
        val offY = sh * 0.48f - StrokeStore.gridH * scale / 2f

        drawing = true
        overlay?.text = "■ Stop"
        // Overlay hat kar thoda wait, phir draw shuru
        handler.postDelayed({ drawStroke(0, scale, offX, offY) }, 400)
    }

    private fun drawStroke(i: Int, scale: Float, offX: Float, offY: Float) {
        val strokes = StrokeStore.strokes
        if (!drawing || i >= strokes.size) {
            drawing = false
            overlay?.text = "▶ Draw"
            return
        }
        val pts = strokes[i]
        val path = Path()
        path.moveTo(offX + pts[0].x * scale, offY + pts[0].y * scale)
        for (k in 1 until pts.size) {
            path.lineTo(offX + pts[k].x * scale, offY + pts[k].y * scale)
        }
        val duration = (pts.size * 12L).coerceIn(60L, 20000L)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()

        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                handler.postDelayed({ drawStroke(i + 1, scale, offX, offY) }, 30)
            }
            override fun onCancelled(g: GestureDescription?) {
                handler.postDelayed({ drawStroke(i + 1, scale, offX, offY) }, 30)
            }
        }, null)
        if (!ok) handler.postDelayed({ drawStroke(i + 1, scale, offX, offY) }, 30)
    }
}
