package com.example.instadoodle

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var preview: ImageView
    private lateinit var info: TextView
    private val PICK = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 80, 48, 48)
        }

        preview = ImageView(this).apply {
            setBackgroundColor(Color.parseColor("#EEEEEE"))
            adjustViewBounds = true
        }
        info = TextView(this).apply {
            text = "Step 1: Accessibility ON karo\nStep 2: PNG chuno\nStep 3: Play dabao, Instagram me doodle screen kholo, ▶ Draw dabao"
            setPadding(0, 24, 0, 24)
        }

        val btnAccess = Button(this).apply {
            text = "1. Accessibility ON karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val btnPick = Button(this).apply {
            text = "2. PNG chuno"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                startActivityForResult(i, PICK)
            }
        }
        val btnPlay = Button(this).apply {
            text = "3. ▶ Play"
            setOnClickListener { play() }
        }

        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(info)
        root.addView(btnAccess)
        root.addView(btnPick)
        root.addView(btnPlay)
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        info.text = "Processing..."
        thread {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            if (bmp == null) {
                runOnUiThread { info.text = "Image nahi khuli" }
                return@thread
            }
            StrokeStore.build(bmp)
            runOnUiThread {
                preview.setImageBitmap(bmp)
                info.text = "Ready! ${StrokeStore.strokes.size} strokes mile. Ab Play dabao."
            }
        }
    }

    private fun play() {
        val svc = DrawService.instance
        if (svc == null) {
            Toast.makeText(this, "Pehle Accessibility me 'Insta Doodle Auto Draw' ON karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (StrokeStore.strokes.isEmpty()) {
            Toast.makeText(this, "Pehle PNG chuno", Toast.LENGTH_SHORT).show()
            return
        }
        svc.showOverlay()
        val launch = packageManager.getLaunchIntentForPackage("com.instagram.android")
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Instagram install nahi hai", Toast.LENGTH_SHORT).show()
    }
}
