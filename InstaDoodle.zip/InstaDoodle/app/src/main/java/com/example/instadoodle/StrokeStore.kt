package com.example.instadoodle

import android.graphics.Bitmap
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.sqrt

/** PNG se strokes (lines) banata hai aur unhe yaad rakhta hai. */
object StrokeStore {
    var strokes: List<List<PointF>> = emptyList()
    var gridW = 1
    var gridH = 1

    /** maxSide bada = zyada detail, par draw hone me zyada time. */
    fun build(src: Bitmap, maxSide: Int = 110, threshold: Int = 90) {
        val scale = maxSide.toFloat() / maxOf(src.width, src.height)
        val w = maxOf(8, (src.width * scale).toInt())
        val h = maxOf(8, (src.height * scale).toInt())
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)

        // Grayscale (transparent pixel = safed)
        val gray = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val p = bmp.getPixel(x, y)
            val a = (p ushr 24) and 0xFF
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val lum = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            gray[y * w + x] = (lum * a + 255 * (255 - a)) / 255
        }

        // Sobel edge detection
        val edge = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            fun g(dx: Int, dy: Int) = gray[(y + dy) * w + (x + dx)]
            val gx = -g(-1, -1) - 2 * g(-1, 0) - g(-1, 1) + g(1, -1) + 2 * g(1, 0) + g(1, 1)
            val gy = -g(-1, -1) - 2 * g(0, -1) - g(1, -1) + g(-1, 1) + 2 * g(0, 1) + g(1, 1)
            val mag = sqrt((gx * gx + gy * gy).toDouble()) / 4.0
            edge[y * w + x] = mag > threshold / 2.0
        }

        // Edge pixels ko jodkar strokes banao
        val visited = BooleanArray(w * h)
        val result = ArrayList<List<PointF>>()
        val nx = intArrayOf(1, 1, 0, -1, -1, -1, 0, 1)
        val ny = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)

        for (sy in 0 until h) for (sx in 0 until w) {
            val si = sy * w + sx
            if (!edge[si] || visited[si]) continue
            val pts = ArrayList<PointF>()
            var cx = sx
            var cy = sy
            visited[si] = true
            pts.add(PointF(cx.toFloat(), cy.toFloat()))
            while (true) {
                var found = false
                for (k in 0 until 8) {
                    val tx = cx + nx[k]
                    val ty = cy + ny[k]
                    if (tx < 0 || ty < 0 || tx >= w || ty >= h) continue
                    val ti = ty * w + tx
                    if (edge[ti] && !visited[ti]) {
                        visited[ti] = true
                        cx = tx; cy = ty
                        pts.add(PointF(cx.toFloat(), cy.toFloat()))
                        found = true
                        break
                    }
                }
                if (!found) break
            }
            if (pts.size >= 4) result.add(simplify(pts))
        }
        strokes = result
        gridW = w
        gridH = h
    }

    /** Har 2nd point rakho (last point hamesha) taaki draw tez ho. */
    private fun simplify(p: List<PointF>): List<PointF> {
        val out = ArrayList<PointF>()
        for (i in p.indices step 2) out.add(p[i])
        if (out.last() != p.last()) out.add(p.last())
        return out
    }
}
